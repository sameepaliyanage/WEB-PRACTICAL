<?php 
$x=4;
$y=6;
$sum= $x + $y;
$diff= $y- $x;
$prod=$x*$y;
$Div=$y/$x;
echo "Sum $sum <br>";
echo "Difference $diff <br>";
echo "Product $prod <br>";
echo "Division $Div<br>";
?>