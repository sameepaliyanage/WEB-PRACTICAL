<?php
$fruits = array("Apple", "Bananas", "Pineapple", "StarFruit");
for ($f = 0; $f < 4; $f++) {
    echo $fruits[$f] . "<br>";
}
?>