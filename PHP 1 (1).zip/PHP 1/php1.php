<?php
$x;
$y;
$sum=$x+$y;
$dif=$y-$x;
$product=$x*$y;
$div=$y/$x;
echo "Sum: $sum <br>";
echo "Difference: $dif <br>";
echo "Product: $product <br>";
echo "Division: $div <br>";
?>