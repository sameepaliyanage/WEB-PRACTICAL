
<html>
<body>


<center>
<?php

$sum=0;

for($a=5;$a<15;$a++)
{	$sum=$sum+$a;
}


echo "The sum of 5 to 15 : $sum <br>";






?>
</center>


</body>
</html>